package com.infosys.myrailways;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="TRAINDATA1.DB";
    public static final String TABLE_NAME="BOOKINGDATA";
    public static final String name="name";
    public static final String email="email";
    public static final String source="source";
    public static final String dest="dest";
    public static final String tdate="tdate";
    public static final String pass="pass";
    public static final String train="train";
    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("db", "creating table");
        db.execSQL(" CREATE TABLE IF NOT EXISTS TRAINBOOKING (Name VARCHAR,Email VARCHAR,Source VARCHAR,Destination VARCHAR,TDate VARCHAR,NUMOFPASS VARCHAR,TrainNO VARCHAR);");
        Log.d("db", "created table");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    public boolean insertdata(String name,String email, String source,String dest,String tdate,String pass, String train)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("Name",name);
        contentValues.put("Email",email);
        contentValues.put("Source",source);
        contentValues.put("Destination",dest);
        contentValues.put("TDate",tdate);
        contentValues.put("NUMOFPASS",pass);
        contentValues.put("TrainNO",train);
     if( db.insert("TRAINBOOKING",null,contentValues)==-1)
     {
         return false;
     }
     else {
         return true;
     }
    }

    public Cursor getalldata()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor d=db.rawQuery("select * from TRAINBOOKING ",null);
        return d;
    }
}
