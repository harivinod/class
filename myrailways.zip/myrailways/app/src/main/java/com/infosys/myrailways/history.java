package com.infosys.myrailways;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class history extends AppCompatActivity {
    DatabaseHelper mydb;
    TextView t1;
    ListView lv;
    @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
lv=findViewById(R.id.listview);
        //t1= findViewById(R.id.txtmsg);
        mydb=new DatabaseHelper(this);
        mydb.getWritableDatabase();
        ArrayList<String> al=new ArrayList<>();
      Cursor c= mydb.getalldata();
      if(c.getCount()==0)
      {
          Toast.makeText(this,"no data",Toast.LENGTH_SHORT).show();
      }
      else
      {

         // t1.setText(sb.toString());


          while(c.moveToNext())
          {
              StringBuffer sb=new StringBuffer();
              sb.append("Train No: "+ c.getString(6)+ "\n");
              sb.append("Name: "+ c.getString(0)+ " Email: " + c.getString(1)+"\n");
              sb.append("Source: "+ c.getString(2)+ " Destination: " + c.getString(3)+"\n");
              sb.append("TDate: "+ c.getString(4)+ " NUMOFPASS: " + c.getString(5)+"\n");
              al.add(sb.toString());
              ListAdapter la=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,al);
              lv.setAdapter(la);
          }

      }
    }
}
