package com.infosys.myrailways;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Booking extends AppCompatActivity {
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    DatabaseHelper mydb;
    TextView txtsource,txtdes,txtdate,txtcount,txttrain;
    Button btntrain,btnbook;

    SQLiteDatabase db;
    Cursor result;
    private static final int SECOND_ACTIVITY_REQUEST_CODE = 0;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout:
                //newGame();
                this.finish();

                return true;
            case R.id.hist:
            Intent i=new Intent(Booking.this,history.class);
            startActivity(i);

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //return super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mymenu,menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SECOND_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                 String returnString = data.getStringExtra("train");
                 txttrain.setText(returnString);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);
        mydb=new DatabaseHelper(this);
        mydb.getWritableDatabase();

        preferences=getSharedPreferences("mydata",MODE_PRIVATE);
        editor=preferences.edit();

        txtsource=findViewById(R.id.txtsource);
        txtdes=findViewById(R.id.txtdest);
        txtdate=findViewById(R.id.txtdate);
        txtcount=findViewById(R.id.txtcount);
        txttrain=findViewById(R.id.txttrain);

        btntrain=findViewById(R.id.btnlist);
        btnbook=findViewById(R.id.btnbook);



        db=openOrCreateDatabase("MYTrainDB",MODE_PRIVATE,null);
        db.execSQL(" CREATE TABLE IF NOT EXISTS TRAINBOOKING (Name VARCHAR, Email VARCHAR, Source VARCHAR, Destination VARCHAR, TDate VARCHAR, NUMOFPASS VARCHAR, TrainNO VARCHAR);");

btntrain.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i=new Intent(Booking.this,trainlist.class);
        startActivityForResult(i,SECOND_ACTIVITY_REQUEST_CODE);
    }
});



        btnbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=preferences.getString("name","NA");
                String email=preferences.getString("email","NA");
                String source=txtsource.getText().toString();
                String dest=txtdes.getText().toString();
                String tdate=txtdate.getText().toString();
                String pass=txtcount.getText().toString();
                String train=txttrain.getText().toString();
                String msg="";
if(mydb.insertdata(name,email,source,dest,tdate,pass,train))
{
    msg="Booking Success!!";
}
else
{
    msg="Booking Failed";
}
               // db.execSQL("insert into TRAINBOOKING Values('" + name + "','" + email + "','" + source + "','" + dest + "','" + tdate + "','" + pass + "','" + train + "') ");
                AlertDialog.Builder builder= new AlertDialog.Builder(Booking.this);
                builder.setTitle("Alert");
                builder.setMessage(msg);
                builder.setCancelable(false);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).show();

            }
        });


    }
}
