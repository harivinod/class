package com.infosys.myrailways;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView txtname,txtemail,txtpwd;
    Button login;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtname = findViewById(R.id.txtname);
        txtemail = findViewById(R.id.txtemail);
        txtpwd = findViewById(R.id.txtpwd);
login=findViewById(R.id.btnlogin);
        preferences=getSharedPreferences("mydata",MODE_PRIVATE);
        editor=preferences.edit();

        String name=preferences.getString("name","NA");
        String email=preferences.getString("email","NA");
        String pwd=preferences.getString("pwd","NA");

        if(name !="NA")
        {
           // Toast.makeText(this,"no name",Toast.LENGTH_SHORT);
            // intent
            Intent i= new Intent(MainActivity.this,Booking.class);
            startActivity(i);

        }
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putString("name",txtname.getText().toString());
                editor.putString("email",txtemail.getText().toString());
                editor.putString("pwd",txtpwd.getText().toString());
                editor.apply();
                Intent i= new Intent(MainActivity.this,Booking.class);
                startActivity(i);

            }
        });

    }


}
