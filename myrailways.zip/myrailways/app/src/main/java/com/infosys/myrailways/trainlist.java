package com.infosys.myrailways;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class trainlist extends AppCompatActivity {
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trainlist);
        lv=findViewById(R.id.trains);

        ArrayList<String> al=new ArrayList<>();
        al.add("Train No: 12345 Source : Hyderabad  Destination : New York");
        al.add("Train No: 45678 Source : Bangalore  Destination : New York");
        al.add("Train No: 67895 Source : Mumbai  Destination : New York");

        ListAdapter la=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,al);
        lv.setAdapter(la);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);
               // Toast.makeText(trainlist.this, selectedItem, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                intent.putExtra("train", selectedItem.replaceAll("\\D+",""));
                setResult(RESULT_OK, intent);
                finish();
            }

        });
    }

}
